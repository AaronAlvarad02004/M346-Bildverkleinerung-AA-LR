// Autor: Damjan Djukic, Maurin Schickli, Cyrill Koller
// Datum: 2022-12-20
// Version: 2.0
// Description: Lambda function to resize images


'use strict';

const AWS = require('aws-sdk');
const sharp = require('sharp');

exports.handler = async (event, context) => {
    // create s3 instance 
    const s3 = new AWS.S3();
    
    // gets original bucket from the event
    const bucket = event.Records[0].s3.bucket.name;
    // console.log(process.env.BUCKET_NAME_ORIGINAL);

    // gets file name from the event
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));

    // gets percentage resize from the environment variable
    let percentageResize = process.env.PERCENTAGE_RESIZE;

    try {
        // gets the image from the bucket
        const data = await s3.getObject({ Bucket: bucket, Key: key }).promise();
        const image = sharp(data.Body);

        // resize image
        const metadata = await image.metadata();
        let size = Math.round(metadata.width * percentageResize / 100);
        console.log(`Resizing ${key} to ${size}`);
        let resizedImage = await image.resize(size).toBuffer();

        // Uploads resized image to the compressed/resized bucket
        await s3.putObject({
            Body: resizedImage,
            Bucket: s3.listObjects(process.env.BUCKET_NAME_COMPRESSED).params,
            Key: `resized-${key}`,
            ContentType: 'image/jpeg'
        }).promise();

        // delete original file in the bucket
        // await s3.deleteObject({
        //     Bucket: bucket,
        //     Key: key
        // }).promise();

        console.log(`Resized ${key} and uploaded to target bucket`);

    } catch (err) {
        console.error(err);
    }
};
